/*
 * main.c
 *
 *  Created on: May 2, 2025
 *      Author: USER
 */


#include "main.h"





int main(void)
{
  hw_init();
  ap_init();

  ap_main();
  return 0;
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) // can 메시지 수신 인터럽트
{
  if (hcan->Instance == CAN1)
    {
      CAN_RxHeaderTypeDef rxHeader;
      uint8_t rxData[8];
      char uartBuf[100];

      HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rxHeader, rxData);

      // 메시지를 문자열로 변환
      snprintf(uartBuf, sizeof(uartBuf),
               "CAN ID: 0x%03X | DATA: %02X %02X %02X %02X %02X %02X %02X %02X\r\n",
               rxHeader.StdId,
               rxData[0], rxData[1], rxData[2], rxData[3],
               rxData[4], rxData[5], rxData[6], rxData[7]);

      // UART2로 송신 (USB-Serial 통해 PC로 전송됨)
      HAL_UART_Transmit(&huart2, (uint8_t*)uartBuf, strlen(uartBuf), HAL_MAX_DELAY);
    }

}
