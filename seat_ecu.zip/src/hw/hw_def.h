/*
 * hw_def.h
 *
 *  Created on: May 2, 2025
 *      Author: USER
 */

#ifndef SRC_HW_HW_DEF_H_
#define SRC_HW_HW_DEF_H_


#include "def.h"
#include "bsp.h"




#endif /* SRC_HW_HW_DEF_H_ */
