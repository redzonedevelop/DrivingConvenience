/*
 * ap.c
 *
 *  Created on: May 5, 2025
 *      Author: USER
 */


#include "ap.h"


uint8_t data[8] = {0, 0, 0, 0, 0, 0, 0, 0};


void ap_init(void)
{
  filter_init(0x7f3, 0x106); // can 필터 생성
  HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING); // 수신 인터럽트 ON
  HAL_CAN_Start(&hcan); // can 모듈 시작
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1); // 서보 모터 좌 제어 시작
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2); // 서보 모터 우 제어 시작
}

void ap_main(void)
{

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

  while(1)
  {
    //send_message(0x102, &data[0]); // can 메시지 전송
    TIM2->CCR1 = 1000;
    TIM2->CCR2 = 400;
    delay(1000);
    TIM2->CCR1 = 750;
    TIM2->CCR2 = 750;
    delay(1000); // 1초 딜레이
    TIM2->CCR1 = 400;
    TIM2->CCR2 = 1000;
    delay(1000);
  }
}
