/*
 * main.c
 *
 *  Created on: May 2, 2025
 *      Author: USER
 */


#include "main.h"





int main(void)
{
	hw_init();
	ap_init();

	ap_main();
	return 0;
}
